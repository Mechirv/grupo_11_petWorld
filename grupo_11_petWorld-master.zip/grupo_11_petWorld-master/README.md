//Una breve descripción de la oferta de productos y/o servicios ofrecidos por su sitio.
Somos una tienda de venta online de productos para mascotas, específicamente gatos y perro.
Nos dedicamos a la venta de alimento, productos de estética, cuidado e higiene, juguetes, accesorios como cuchas, transportadores

//También agregar una breve descripción del público al que apunta el sitio.
Apuntamos a todas aquellas personas que amen a sus mascotas

//Links:
https://headsupfortails.com/collections/kong?custom_constraint=custom-filter+price=0-1221000 => Elegimos esta página por el carrito de compras.

https://happypets.ar/?gclid=Cj0KCQjw-LOEBhDCARIsABrC0TlUTyNe5agx4usf-Xcaj9Zewb6Y9HTKhXT33spuTHdvTEkZayBPOlEaApw7EALw_wcB => Elegimos esta página por el Home.

https://www.mitiendademascotas.com/web/ => Elegimos esta página por la estética del sitio, tanto por la tipografía y por todas las opciones de colores que nos da.

https://playground.digitalhouse.com/login => elegimos esta página por el formato del login

https://www.laika.com.uy/perros?cat=229 => Elegimos ésta página por la temática

//Una breve descripción de los integrantes del equipo.

Soy Mercedes Rodríguez Vivanco, tengo 35 años, soy de Gualeguay, Entre Ríos. Soy Ingeniera en Sistemas de Información y actualmente trabajo en el Poder Judicial. Si bien en la carrera ttuve programación nunca me dediqué a programar, siendo algo que me quedó pendiente, motivo por el cual decidí empezar el curso.

Soy Facundo Moreno, tengo 19 años, soy de Buenos Aires, Argentina. Me adentre en este curso ya que uno de mis sueños, es programar y espero no solo hacer esto con páginas web, sino también con el mayor mercado actualmente, los videojuegos.

Soy Matías Haidbañer, tengo 38 años y soy de Buenos Aires. Me intereso el curso por la salida laboral que tiene y tambien para refrescar mis conocimientos sobre programación. Además de esto, soy periodista deportivo

// Link del tablero:
https://trello.com/invite/b/uJyurSLc/58780dbcdad8cd0ba69cb90c4317b444/petworld
