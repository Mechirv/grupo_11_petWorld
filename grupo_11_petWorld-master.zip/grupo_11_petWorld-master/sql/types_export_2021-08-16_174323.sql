insert into `types` (`id`, `name`) values (1, 'Perros');
insert into `types` (`id`, `name`) values (2, 'Gatos');
insert into `types` (`id`, `name`) values (3, 'Perros y Gatos');
;
