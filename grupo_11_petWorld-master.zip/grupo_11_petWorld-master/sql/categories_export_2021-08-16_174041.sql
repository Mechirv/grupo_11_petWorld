insert into `categories` (`id`, `name`) values (1, 'Alimentos');
insert into `categories` (`id`, `name`) values (2, 'Estetica e Higiene');
insert into `categories` (`id`, `name`) values (3, 'Juguetes y Accesorios');
;
