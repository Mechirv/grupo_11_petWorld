Reunión día sábado 19/06

-Analizamos lo realizado hasta el momento, realizando un listado de las tareas pendientes
-Completamos el tablero de trabajo
-Acordamos división de las tareas pendientes
-Hablamos sobre el feedback del sprint anterior


tareas para hoy 19/06
Mechi: vista productCreate, vista productModify, home (css+html)
Facu: rutas y controlador productDetail, productCart, login, register


reunión día 02/07
-Analizamos lo realizado hasta el momento, realizando un listado de las tareas pendientes
-Completamos el tablero de trabajo
-Acordamos división de las tareas pendientes

tareas:
Facu: ruta/vista para eliminar un producto
Mechi: terminar vista productModify

SPRINT 6:
no hubo reuniones ya que quedé sola en el grupo


