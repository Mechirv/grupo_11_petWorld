Cosas que hicimos bien en el primer sprint
-coordinación de las tareas a realizar
-buena comunicación


Qué hicimos mal
-Pocas reuniones

Que deberíamos comenzar a hacer-
-Reuniones periódicas


Que debemos dejar de hacer

SPRINT 3
Qué hicimos mal
-Pocas reuniones
-

Que mejoramos:
-organizacion y división de tareas


SPRINT 4:
Que hicimos mal:
estuvimos mas desconectados que en los sprint anteriores

Que hicimos bien:
trabajamos mas en forma ocnjunta, aprovechamos las clases para adelantar trabajo

Que deberíamos comenzar a hacer:
mas reuniones, organizar mejor el trabajo

SPRINT 5:
Que hicimos mal: 
nuevamente estuvimos menos coordinados y mas desconectados que en los sprint anteriores.

Que hicimos bien:
aprovechar las clases prácticas

Que deberíamos comenzar a hacer:
-hacer mas reuniones
ytabajar de manera colaborativa
mejorar la división de tareas

SPRINT 6:
Que hicimos mal: 
nuevamente estuvimos menos coordinados y mas desconectados que en los sprint anteriores.
Estuve desorganizada y empecé tarde con el sprint

Que hicimos bien:
aprovechar las clases prácticas para adelantar trabajo 

Que deberíamos comenzar a hacer:
-Planificar mejor el trabajo
-No dejar todo para lo último
-Comenzar el siguiente sprint ni bien termina el anterior

SPRINT 7:
Que hicimos mal:
mala gestión del tiempo

Que hicimos bien:
mejor organización con las tareas



Que deberíamos empezar a hacer:
mejorar la gestión del tiempo
Planificar mejor el trabajo


